var drinkName = "NA";

function validateIp(object, type, nameType){
    var regExName = /^[a-zA-Z]+$/;
    var regExEmail = /([\w\.]+)@([\w\.]+)\.(\w+)/;
	var regExPhone = /\d{3}-?\d{3}-\d{4}$/;
    var regExZip = /^([0-9]{5})$/;

    var name = 'errorMsg'+nameType;
    switch(type) {
        case 1:
            if(!object.value.trim().match(regExName)) {
                object.style.border = "3px solid red";
                document.getElementById(name).style.display = "block";
            } else {
                object.style.border = "";
                document.getElementById(name).style.display = "none";
            }
        break;
        
        case 2:
            var emailID = document.getElementsByName("emailId")[0];
            let domain = emailID.value.split("@")[1];
            if(emailID.value.match(regExEmail) && domain == "northeastern.edu") {
                emailID.style.border = "";
                document.getElementById(name).style.display = "none";
            } else  {
                emailID.style.border = "3px solid red";
                document.getElementById(name).style.display = "block";
            }
        break;
        
        case 3:
            if(!object.value.match(regExPhone)) {
                object.style.border = "3px solid red";
                document.getElementById(name).style.display = "block";
            } else {
                object.style.border = "";
                document.getElementById(name).style.display = "none";
            }
        break;
        
        case 4:
            if(!object.value.match(regExZip)) {
                object.style.border = "3px solid red";
                document.getElementById(name).style.display = "block";
            } else {
                object.style.border = "";
                document.getElementById(name).style.display = "none";
            }
        break;
        
        case 5:
            if(object.value == null || object.value == "") {
                object.style.border = "3px solid red";
                document.getElementById(name).style.display = "block";
            } else {
                object.style.border = "";
                document.getElementById(name).style.display = "none";
            }
        break;
    }
}

function confirmInput(){
    var radios = document.getElementsByName("title");
    var formValid = true;

    var i = 0;
    while (!formValid && i < radios.length) {
        if (radios[i].checked) formValid = true;
        i++;        
    }

    if (!formValid) {
        
        document.getElementById("errorRadio").style.display = "none";

    }else{
        document.getElementById("errorRadio").style.display = "block";
        return false;
    }  
}

function onCheck(checkboxElem) {
    var textField = document.getElementById("hiddenTextField");
    var addinfo =  document.getElementById("addInfo");
    if (checkboxElem.checked) {
        textField.style.display = "block";
    
    } else {
        textField.style.display = "none";
        addinfo.value = "";
    }
}

function trialMethod(){
    console.log("on submit click");
    var table = document.getElementById("myTable");
    var title = document.querySelector('input[name = "title"]:checked').value;
    var fname = document.getElementsByName("firstName")[0].value;
    var lname = document.getElementsByName("lastName")[0].value;
    var emailID = document.getElementsByName("emailId")[0].value;
    var phone = document.getElementsByName("phoneNumber")[0].value;
    var streetAddr1 = document.getElementsByName("streetAddress1")[0].value;
    var streetAddr2 = document.getElementsByName("streetAddress2")[0].value;
    var city = document.getElementsByName("city")[0].value;
    var state = document.getElementsByName("state")[0].value;
    var zipcode = document.getElementsByName("zipcode")[0].value;

    var text = document.getElementsByName("text")[0].value;
    var source = document.querySelector('input[name = "source"]:checked').value;
    var drink = drinkName!="" || drinkName!= null || drinkName!= undefined ? drinkName : NA;
    var addinfo =  document.getElementById("addInfo").value;

    if(title =="" || fname ==""|| lname ==""|| emailID ==""|| phone ==""|| zipcode ==""|| city ==""|| 
        state ==""|| streetAddr1 ==""|| text ==""|| source ==""){
        alert("Please fill all the details")
    }
    else{
        table.style.display = "block"
        var row = table.insertRow(1);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);
        var cell5 = row.insertCell(4);
        var cell6 = row.insertCell(5);
        var cell7 = row.insertCell(6);
        var cell8 = row.insertCell(7);
        var cell9 = row.insertCell(8);
        var cell10 = row.insertCell(9);
        var cell11 = row.insertCell(10);
        var cell12 = row.insertCell(11);
        var cell13 = row.insertCell(12);
        var cell14 = row.insertCell(13);
        
        cell1.innerHTML = title;
        cell2.innerHTML = fname;
        cell3.innerHTML = lname;
        cell4.innerHTML = emailID;
        cell5.innerHTML = phone;
        cell6.innerHTML = streetAddr1;
        cell7.innerHTML = streetAddr2;
        cell8.innerHTML = city;
        cell9.innerHTML = state;
        cell10.innerHTML = zipcode;
        cell11.innerHTML = source;
        cell12.innerHTML = text;
        cell13.innerHTML = drink;
        cell14.innerHTML = addinfo;

        var frm = document.getElementById('feedback-form');
        frm.reset(); 
        document.getElementById("chkboxDiv1").style.display = "none";
        document.getElementById("chkboxDiv2").style.display = "none";
        document.getElementById("chkboxDiv3").style.display = "none";
        document.getElementById("chkboxDiv4").style.display = "none";
        document.getElementById("chkboxDiv5").style.display = "none";
        document.getElementById("hiddenTextField").style.display = "none";
    }
}

function dropDownList(){
    var coffee = document.getElementById("coffee").value;
    if(coffee =="Espresso"){
        document.getElementById("chkboxDiv1").style.display = "none";
        document.getElementById("chkboxDiv2").style.display = "none";
        document.getElementById("chkboxDiv3").style.display = "block";
        document.getElementById("chkboxDiv4").style.display = "none";
        document.getElementById("chkboxDiv5").style.display = "none";
        drinkName = coffee;
    }         
    else if(coffee == "Mocha"){
        document.getElementById("chkboxDiv1").style.display = "block";
        document.getElementById("chkboxDiv2").style.display = "none";
        document.getElementById("chkboxDiv3").style.display = "none";
        document.getElementById("chkboxDiv4").style.display = "none";
        document.getElementById("chkboxDiv5").style.display = "none";
        drinkName = coffee;
    }      
    else if(coffee == "Latte"){
        document.getElementById("chkboxDiv1").style.display = "none";
        document.getElementById("chkboxDiv2").style.display = "block";
        document.getElementById("chkboxDiv3").style.display = "none";
        document.getElementById("chkboxDiv4").style.display = "none";
        document.getElementById("chkboxDiv5").style.display = "none";
        drinkName = coffee;
    }
    else if(coffee == "Milk"){
        document.getElementById("chkboxDiv1").style.display = "none";
        document.getElementById("chkboxDiv2").style.display = "none";
        document.getElementById("chkboxDiv3").style.display = "none";
        document.getElementById("chkboxDiv4").style.display = "block";
        document.getElementById("chkboxDiv5").style.display = "none";
        drinkName = coffee;
    }       
    else if(coffee == "Tea"){
        document.getElementById("chkboxDiv1").style.display = "none";
        document.getElementById("chkboxDiv2").style.display = "none";
        document.getElementById("chkboxDiv3").style.display = "none";
        document.getElementById("chkboxDiv4").style.display = "none";
        document.getElementById("chkboxDiv5").style.display = "block";
        drinkName = coffee;
            
    }
    else {
        document.getElementById("chkboxDiv1").style.display = "none";
        document.getElementById("chkboxDiv2").style.display = "none";
        document.getElementById("chkboxDiv3").style.display = "none";
        document.getElementById("chkboxDiv4").style.display = "none";
        document.getElementById("chkboxDiv5").style.display = "none";
        document.getElementById("addInfo").value = "";
        document.getElementById("hiddenTextField").style.display = "none";

    }
}