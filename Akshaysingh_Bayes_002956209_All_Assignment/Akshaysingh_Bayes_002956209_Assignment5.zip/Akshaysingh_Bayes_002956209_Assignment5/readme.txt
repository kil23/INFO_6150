HTML and CSS tags used : 

HTML
head
body
title
a 
p
section
div
img
nav
header
footer
script
ul
li
i 
em
strong
h2
figure
figcaption
span
meta
form
input
tel 
mailto
link

Bootstrap5: 
carousal
navbar
cards
containers
button
button-group
img
colors
Input groups
forms
