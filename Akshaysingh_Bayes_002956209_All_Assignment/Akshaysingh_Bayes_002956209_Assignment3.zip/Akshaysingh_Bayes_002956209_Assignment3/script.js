//Title constructor function that creates a Title object
function Title(t1) 
{ this.mytitle = t1;
}

Title.prototype.getName = function () { 
return (this.mytitle);
}

var socialMedia = {
  facebook : 'http://facebook.com',
  twitter: 'http://twitter.com',
  flickr: 'http://flickr.com',
  youtube: 'http://youtube.com'
};

var t = new Title("CONNECT WITH ME!");
var toggleCount = 0;
var editCol = document.getElementById("editCol");
var delCol = document.getElementById("delCol");
var submitButton = document.getElementById("button");
var tableParent = document.getElementById("myTable");
var firstRow = tableParent.rows[1].cloneNode(true);
var studInfo = tableParent.rows[2].cloneNode(true);

function addNewStudent() {
  console.log("Add new button was pressed");
  var tableParent = document.getElementById("myTable");
  var length = tableParent.rows.length;
  if(length === 1) {
    createNewStudentRecord();
  } else {
    var new_row = tableParent.rows[length - 2].cloneNode(true);
    var studentInfo = tableParent.rows[length - 1].cloneNode(true);
    var rowId = parseInt(new_row.id) + 1;
    new_row.cells[1].innerHTML = "Student" + " " + rowId;
    new_row.cells[2].innerHTML = "Teacher" + " " + rowId;
    new_row.cells[6].innerHTML = Math.floor(Math.random()*90000) + 10000;
    new_row.id = rowId;
    studentInfo.id = 'addInfo' + ((length + 1) / 2);
    tableParent.appendChild(new_row);
    tableParent.appendChild(studentInfo);
    console.log(length, new_row, studentInfo);
  }
  return true;
}

function createNewStudentRecord() {
  var tableParent = document.getElementById("myTable");
  tableParent.appendChild(firstRow);
  tableParent.appendChild(studInfo);
  return true;
}

function addStudent() {
  try {
    if(addNewStudent()) {
      alert("New Student record added!!");
    }
  } catch(err) {
    console.log(err);
    alert("Error while adding new record!!");
  }
}

function showHiddenRow(rowId) {
  console.log(rowId);
  var hidRow = rowId.parentElement.parentElement.nextElementSibling;
  if (hidRow.style.display === "none") {
    hidRow.style.display = "block";
  } else {
    hidRow.style.display = "none";
  }
}

function editRow(rowId) {
  btnEnableDisable(toggleCount);
  alert("Editing this row!!");
}

function delRow(rowId) {
  var row = rowId.parentNode.parentNode;
  var sibRow = row.nextElementSibling;
  row.parentNode.removeChild(row);
  sibRow.parentNode.removeChild(sibRow);
  toggleCount -= 1;
  btnEnableDisable(toggleCount);
  alert("Deleted selected record!!");
}

function rowSelect(rowId) {

  var a = rowId.parentNode.parentNode;

  if (rowId.checked) {
    toggleCount += 1;
    btnEnableDisable(toggleCount);
    a.lastElementChild.previousElementSibling.removeAttribute("class");
    a.lastElementChild.removeAttribute("class");
    a.style.backgroundColor = "yellow";
  }
  else {
    toggleCount -= 1;
    btnEnableDisable(toggleCount);
    a.style.backgroundColor = "white";
    a.lastElementChild.classList.add("delete");
    a.lastElementChild.previousElementSibling.classList.add("edit");
  }
}

function btnEnableDisable(toggleCount) {
  var submitBtn = document.getElementById("button");
  if (toggleCount >= 1) {
    submitBtn.style.border = "2px solid orange";
    submitBtn.style.backgroundColor = "orange";
    submitButton.removeAttribute("disabled");
    delCol.removeAttribute("class");
    editCol.removeAttribute("class");
  }
  else {
    submitBtn.style.removeProperty("border");
    submitBtn.style.removeProperty("background-color");
    delCol.classList.add("delete");
    editCol.classList.add("edit");
  }

}