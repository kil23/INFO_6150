HTML tags used in the project :

html 
header
body
title
script
table, tr, th, td
small
h1, h2, h3, h4, h5, h6
link
a
img
p
form
label
input
u
i
button

HTML5 tags :

section
video
audio
nav
figure
figcaption
button
footer
iframe
dialog
favicon