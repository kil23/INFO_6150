import React, { Component } from 'react'
import './login.css'
import { Link } from 'react-router-dom';

class Label extends React.Component {
    render() {
        var labelStyle = {
            fontFamily: "sans-serif",
            fontWeight: "bold",
            padding: 13,
            margin: 0
        };
        
        return (
            <p style={labelStyle}>{this.props.color}</p>
        );
    }
}

class Card extends React.Component {
    render() {
        var cardStyle = {
            height: 100,
            width: 350,
            padding: 0,
            backgroundColor: "#FFF",
            WebkitFilter: "drop-shadow(0px 0px 5px #666)",
            filter: "drop-shadow(0px 0px 5px #666)"
        };

        return (
            <div style={cardStyle}>
                <Label color={this.props.color}/>
            </div>
        );
    }
}

export class Login extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
             isLoggedIn: false
        }
    }
    

    showWelcome(props) {
        console.log("Welcome!!!")
        this.setState({
            isLoggedIn: true
        })
    }

    render() {
        return (
            
            <form>
                <div>
                    <Card color="This is the login page. Please login with your credentials"/>
                    <br></br>
                </div>

                <h3>Log in</h3>

                <div className="form-group">
                    <label>Email</label>
                    <input type="email" className="form-control" placeholder="Enter email" />
                </div>

                <div className="form-group">
                    <label>Password</label>
                    <input type="password" className="form-control" placeholder="Enter password" />
                </div>

                <div className="form-group">
                    <div className="custom-control custom-checkbox">
                        <input type="checkbox" className="custom-control-input" id="customCheck1" />
                        <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
                    </div>
                </div>

                

                <Link to={"/jobs"}>
                    <button type="submit" className="btn btn-dark btn-lg btn-block">
                    Sign in<span class="badge badge-light">*</span></button>
                </Link>
                
                <p className="forgot-password text-right">
                    Forgot <a href="">password?</a>
                </p>

            </form>
        );
    }
}

export default Login
