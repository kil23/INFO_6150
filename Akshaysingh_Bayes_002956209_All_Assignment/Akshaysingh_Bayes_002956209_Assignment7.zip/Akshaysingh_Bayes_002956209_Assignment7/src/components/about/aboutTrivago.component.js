import React, { Component } from 'react';
//import './login.css';

class Label extends React.Component {
    render() {
        var labelStyle = {
            fontFamily: "sans-serif",
            fontWeight: "bold",
            padding: 13,
            margin: 0
        };
        
        return (
            <p style={labelStyle}>{this.props.color}</p>
        );
    }
}

class Card extends React.Component {
    render() {
        var cardStyle = {
            height: 200,
            width: 350,
            padding: 0,
            backgroundColor: "#FFF",
            WebkitFilter: "drop-shadow(0px 0px 5px #666)",
            filter: "drop-shadow(0px 0px 5px #666)"
        };

        return (
            <div style={cardStyle}>
                <Label color={this.props.color}/>
            </div>
        );
    }
}

export class About extends Component {
    render() {
        return (
            <div>
                <p>Hi There! You are viewing Trivago's official website!</p>

                <div>
                    <Card color="Trivago made for travel junkies. This website is for all types of travel junkies. 
                    The gist of the website is to share information related to travel and food and add photos. 
                    Users are allowed to share their experiences in form of blogs."/>
                </div>

            </div>
        )
    }
}

export default About
