import React, { Component } from 'react';

class Label extends React.Component {
    render() {
        var labelStyle = {
            fontFamily: "sans-serif",
            fontWeight: "bold",
            padding: 13,
            margin: 0
        };
        
        return (
            <p style={labelStyle}>{this.props.color}</p>
        );
    }
}

class Card extends React.Component {
    render() {
        var cardStyle = {
            height: 50,
            width: 350,
            padding: 0,
            backgroundColor: "#FFF",
            WebkitFilter: "drop-shadow(0px 0px 5px #666)",
            filter: "drop-shadow(0px 0px 5px #666)"
        };

        return (
            <div style={cardStyle}>
                <Label color={this.props.color}/>
            </div>
        );
    }
}

const textAreaStyles = {
    width: 235,
    margin: 5
  };

export class Jobs extends Component {
    
    // constructor(props) {
    //     super(props)
    //     const jobs = ['SDE','UI Dev','Tester','Manager']
    //     this.state = {
    //          jobs: jobs
    //     }
    // }
    constructor(props) {
        super(props);
        // change code below this line
        this.state = {
        userInput: '',
        toDoList: []
        };
        // change code above this line
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleSubmit() {
        const itemsArray = this.state.userInput.split(',');
        this.setState({
          toDoList: itemsArray
        });
    }
    handleChange(e) {
        this.setState({
          userInput: e.target.value
        });
    }

    // render(props) {
    //     const items = this.state.toDoList.map(function(item){
    //         return <li> {item} </li>;
    //       });
    //     return (
    //         <div>
    //             <p>Welcome user!</p>
    //             <div>
    //                 <Card color="You are viewing jobs page"/>
    //                 <br></br>
    //             </div>
    //         </div>
    //     )
    // }
    render() {
        const items = this.state.toDoList.map(function(item){
          return <li> {item} </li>;
        });
        return (
          <div>
              <div>
                <Card color="You are viewing jobs page"/>
                <br></br>
                </div>
            <textarea
              onChange={this.handleChange}
              value={this.state.userInput}
              style={textAreaStyles}
              placeholder="Separate Items With Commas" /><br />
            <button onClick={this.handleSubmit}>Create Jobs</button>
            <br></br>
            <br></br>
            <h3>Jobs List:</h3>
            <ul>
              {items}
            </ul>
          </div>
        );
      }
}

export default Jobs
