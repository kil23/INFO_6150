import React, { Component } from 'react'


class Label extends React.Component {
    render() {
        var labelStyle = {
            fontFamily: "sans-serif",
            fontWeight: "bold",
            padding: 13,
            margin: 0
        };
        
        return (
            <p style={labelStyle}>{this.props.color}</p>
        );
    }
}

class Card extends React.Component {
    render() {
        var cardStyle = {
            height: 100,
            width: 350,
            padding: 0,
            backgroundColor: "#FFF",
            WebkitFilter: "drop-shadow(0px 0px 5px #666)",
            filter: "drop-shadow(0px 0px 5px #666)"
        };

        return (
            <div style={cardStyle}>
                <Label color={this.props.color}/>
            </div>
        );
    }
}

export class Contact extends Component {
  render() {
    return (
      <div>
          Contact Details : 
          <div>
            <Card color="For more information, please contact us at official@trivago.com or reach us at +1-(666)-666-6666"/>
            <br></br>
          </div>
      </div>
    )
  }
}

export default Contact