Purpose of website:

Website is for travel junkies. The gist of the website is to share information related to travel and food. Users are allowed to share their experiences in form of blogs.
A signed in user can write a blog about the recent travel and the food that he/she experienced. User can also read/comment on other blogs too. 


Bootstrap 5

navbar:-
Documentation and examples for Bootstrap’s powerful, responsive navigation header, the navbar. Includes support for branding, navigation, and more, including support for our collapse plugin.nav and tabs:-
Documentation and examples for how to use Bootstrap’s included navigation components.

form:-
Examples and usage guidelines for form control styles, layout options, and custom components for creating a wide variety of forms.

collapse:-
The collapse JavaScript plugin is used to show and hide content. Buttons or anchors are used as triggers that are mapped to specific elements you toggle.button:-
Use Bootstrap's custom button styles for actions in forms, dialogs, and more with support for multiple sizes, states, and more.

card:-
A card in Bootstrap 4 is a bordered box with some padding around its content. It includes options for headers, footers, content, colors, etc.

alert:-
styles for success, warning, and error messages

close button:-
A generic close button for dismissing content like modals and alerts.Provide an option to dismiss or close a component with .btn-close.

tooltip:-
Documentation and examples for adding custom Bootstrap tooltips with CSS and JavaScript using CSS3 for animations and data-attributes for local title storage.

badge:-
While the styling of badges provides a visual cue as to their purpose, these users will simply be presented with the content of the badge.

accordion:-
The accordion is a graphical control element comprising a vertically stacked list of items, such as labels. Each item can be "expanded" or "collapsed" to reveal the content associated with that item. There can be zero expanded items, exactly one, or more than one item expanded at a time, depending on the configuration.

spinner:-
Bootstrap “spinners” can be used to show the loading state in your projects. They’re built only with HTML and CSS, meaning you don’t need any JavaScript to create them. You will, however, need some custom JavaScript to toggle their visibility.